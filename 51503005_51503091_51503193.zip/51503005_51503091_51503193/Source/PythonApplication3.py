import pandas as pd
import csv
import random
import math
import datetime
import calendar
import numpy as np
from dateutil.parser import parse
from sklearn.metrics import confusion_matrix 
from sklearn.model_selection import train_test_split 
from sklearn.tree import DecisionTreeClassifier 
from sklearn.metrics import accuracy_score 
from sklearn.metrics import classification_report


##############  KMEANS #############################################################################

centroids = []
MAX_ITERATIONS = 100
labels = []



def kmean(data, k):
    numFeatures = len(data)
    centroids = getRandomCentroids(data, numFeatures, k)
    
    iterations = 0
    oldCentroids = None

    # Run the main k-means algorithm
    while not shouldStop(oldCentroids, centroids, iterations):
        # Save old centroids for convergence test. Book keeping.
        oldCentroids = centroids
        iterations += 1
        
        # Assign labels to each datapoint based on centroids
        labels = getLabels(data, centroids)
        
        # Assign centroids based on datapoint labels
        centroids = getCentroids(data, labels, k)
        
    # We can get the labels too by calling getLabels(dataSet, centroids)
    return labels

def getRandomCentroids(dateaset, numFeature, k):
    lst = []
    cen = []
    for i in range(numFeature):
        lst.append(i)
    tmp = random.sample(lst,k)
    for x in tmp:
        cen.append(dateaset[x])
    return cen

def shouldStop(oldCentroids, centroids, iterations):
    if iterations > MAX_ITERATIONS: 
        return True
    return oldCentroids == centroids

def getLabels(dataSet, centroids):
    lab = [[] for i in range(len(centroids))]
    for dat in dataSet:
        min = None
        for i in range(len(centroids)):
            tmp = distance(dat,centroids[i])
            if min == None:
                min = i
            else:
                if tmp < distance(dat,centroids[min]):
                    min = i
        lab[min].append(dat)
    return  lab

def distance(p1, p2):
    re = 0
    for i in range(len(p1)):
        re += abs(float(p1[i])-float(p2[i]))
    return re


def getCentroids(dataSet, labels, k):
    cen = []
    for i in range(k):
        tmpcen = []
        for j in range(len(labels[i][0])):
            avg = 0
            sum = 0
            for x in range(len(labels[i])):
                sum += float(labels[i][x][j])
            avg = sum/len(labels[i])
            tmpcen.append(avg)
        cen.append(tmpcen)
    return cen

#############################################################################################################



     ##
      ###
############
##############  CLUSTERING EVENTS
############
      ###
     ##




#events = pd.read_csv('events.csv')
#available_event_id = pd.read_csv('event_id.csv')
#for i in range(len(available_event_id)):
#    b = available_event_id['event_id'][i]
#    c = events[events['event_id']==b]
#    c.to_csv('preprocessing_event.csv', mode='a')

#smooth_data = pd.read_csv('preprocessing_event.csv')
#smooth_data.drop(['no','zip','city','state','country'],axis=1,inplace=True)

#smooth_data.to_csv('event_processing.csv',index=False, header=False)

#data = []

#with open('event_processing.csv', newline='') as csvfile:
#    spamreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
#    for row in spamreader:
#        data.append(row[0].split(","))
#for dat in data:
#    for j in range(len(dat)):
#        if dat[j] == '':
#            dat[j] = 0

#for dat in data:
#    date = datetime.datetime.strptime(dat[2], '%Y-%m-%dT%H:%M:%S.%fZ')
#    dat[2] = calendar.timegm(date.utctimetuple())

#event_cluster = kmean(data,10)


#for x in range(len(event_cluster)):
#    eidcl = []
#    uidcl = []
#    for y in range(len(event_cluster[x])):
#        eidcl.append(event_cluster[x][y][0])
#        uidcl.append(event_cluster[x][y][1])
#    tm = pd.DataFrame({'event_id': eidcl, 'user_id': uidcl, 'cluster': np.full(len(eidcl),x,dtype=int)})
#    if x == 0:
#        tm.to_csv('event_cluster.csv', mode='a', index=False)
#    else:
#        tm.to_csv('event_cluster.csv', mode='a', index=False, header=False)


#####################################################################################################################




     ##
      ###
############
##############  CLUSTERING USER
############
      ###
     ##

#users = pd.read_csv('users.csv')
#locales = pd.read_csv('locales.csv')

#users.drop('location',axis=1,inplace=True)
#users.to_csv('user_processing.csv', mode='a', index=False, header=False)

#data = []

#with open('user_processing.csv', newline='') as csvfile:
#    spamreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
#    for row in spamreader:
#        data.append(row[0].split(","))
#for dat in data:
#    ulc = dat[1]
#    tmp = ulc.split('_')
#    check = 0
#    if len(tmp)>1:
#        str = tmp[0] + '-' + tmp[1]
#    else:
#        str = tmp[0]
#    for i in range(len(locales)):
#        if locales['locale'][i] == str:
#            dat[1] = locales['decimal_value'][i]
#            check = 1
#            break
#    if check == 0 or dat[1] == '' or dat[1] == 'None':
#        dat[1] = 0


#    if dat[2] == '' or dat[2] == 'None' or type(dat[2]) != int:
#        dat[2] = 1990

#    gender = dat[3]
#    if gender == 'male':
#        dat[3] = 1
#    else:
#        dat[3] = 0


#    join = dat[4]
#    if join == 'None' or join == '':
#        dat[4] = 0
#    else:
#        date = datetime.datetime.strptime(join, '%Y-%m-%dT%H:%M:%S.%fZ')
#        dat[4] = calendar.timegm(date.utctimetuple())


#    if dat[5] == '' or dat[5] == 'None':
#        dat[5] = 0
  


#user_cluster = kmean(data,3)


#for x in range(len(user_cluster)):
#    uidcl = []
#    for y in range(len(user_cluster[x])):
#        uidcl.append(user_cluster[x][y][0])
#    tm = pd.DataFrame({'user_id': uidcl, 'cluster': np.full(len(uidcl),x,dtype=int)})
#    if x == 0:
#        tm.to_csv('user_cluster.csv', mode='a', index=False)
#    else:
#        tm.to_csv('user_cluster.csv', mode='a', index=False, header=False)    

####################################################################################################


    ##
      ###
############
##############  PROCESS TRAINING
############
      ###
     ##



#train = pd.read_csv('train.csv')
#user_clus = pd.read_csv('user_cluster.csv')
#event_clus = pd.read_csv('event_cluster.csv')


#ecl = []
#ucl = []
#timestamp = []

#for i in range(len(train)):
#    utmp = user_clus[user_clus['user_id']==train['user'][i]]
#    if utmp.isnull().values.any():
#        ur = 0
#    else:
#        ur = utmp['cluster'].values[0]
#    ucl.append(ur)
#    

#    etmp = event_clus[event_clus['event_id']==train['event'][i]]
#    er = 0
#    er = etmp['cluster'].values[0]
#    ecl.append(er)


#    timetmp = train['timestamp'][i]
#    date = parse(timetmp)
#    timestamp.append(calendar.timegm(date.utctimetuple()))




#train['user'] = ucl
#train['event'] = ecl
#train['timestamp'] = timestamp
#train.drop(['not_interested'],axis=1,inplace=True)

#train.to_csv('train_processed.csv', mode='a', index=False)  

###################################### OLD (CLUSTERING)

#data = []

#table = pd.read_csv('result_cluster.csv')
#for i in range(len(table)):
#    tmp = []
#    tmp.append(table['user'][i])
#    tmp.append(table['event'][i])
#    tmp.append(table['invited'][i])
#    tmp.append(table['timestamp'][i])
#    tmp.append(table['user_cluster'][i])
#    tmp.append(table['event_cluster'][i])
#    data.append(tmp)

#for dat in data:
#    timestamp = dat[3]
#    if timestamp == '':
#        dat[3] = 0
#    else:
#        date = parse(timestamp)
#        dat[3] = calendar.timegm(date.utctimetuple())

#result = kmean(data,2)


#for x in range(len(result)):
#    user = []
#    event = []
#    invited = []
#    
#    for y in range(len(result[x])):
#        user.append(result[x][y][0])
#        event.append(result[x][y][1])
#        invited.append(result[x][y][2])
#    tm = pd.DataFrame({'user': user, 'event' : event, 'invited' : invited, 'interested': np.full(len(user),x,dtype=int)})
#    if x == 0:
#        tm.to_csv('result.csv', mode='a', index=False)
#    else:
#        tm.to_csv('result.csv', mode='a', index=False, header=False)

####################################################################################################


    ##
      ###
############
##############  TEST RESULT
############
      ###
     ##


#result = pd.read_csv('result.csv')
#train = pd.read_csv('train.csv')

#re = 0
#size = len(result)

#for i in range(size):
#    pretmp = train[train['user']==result['user'][i]]
#    tmp = pretmp[pretmp['event']==result['event'][i]]
#    if tmp['interested'].values[0] == result['interested'][i]:
#        re += 1
#print(re/size)

#Import the dataset 
dataset = pd.read_csv('train_processed.csv')
#We drop the animal names since this is not a good feature to split the data on
###########################################################################################################
##########################################################################################################
"""
Split the data into a training and a testing set
"""
train_features = dataset.iloc[:10000,:-1]
test_features = dataset.iloc[10000:,:-1]
train_targets = dataset.iloc[:10000,-1]
test_targets = dataset.iloc[10000:,-1]
###########################################################################################################
##########################################################################################################
"""
Train the model
"""
tree = DecisionTreeClassifier(criterion = 'entropy').fit(train_features,train_targets)
###########################################################################################################
##########################################################################################################
"""
Predict the classes of new, unseen data
"""
prediction = tree.predict(test_features)
###########################################################################################################
##########################################################################################################
"""
Check the accuracy

Decision tree algorithm

"""
print("The prediction accuracy is: ",tree.score(test_features,test_targets)*100,"%")
###########################################################################################################
##########################################################################################################
"""
This is Bayes algorithm

gaunb = GaussianNB()
gaunb = gaunb.fit(train_features, train_targets)

prediction = gaunb.predict(test_features)

print("The prediction accuracy is: ",gaunb.score(test_features,test_targets)*100,"%")
"""
