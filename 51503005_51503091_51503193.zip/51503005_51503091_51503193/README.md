
## Notes:

 - The main dataset also contains events.csv with 1.2Gb, but we had data cleaning for preprocessing so we don't attach with the source code (File size limit of 100.00MB).
 - The Report.docx describes the process and result of our project.

