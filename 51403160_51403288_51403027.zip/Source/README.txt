﻿Các bước chạy chương trình:
1. cd vào thư mục ./Source bằng console
2. chạy lệnh "python housepredict.py" sau khi cài các thư viện như: seaborn, panda, numpy, scikitlearn
3. dữ liệu sau khi được dự đoán sẽ được lưu trong file processed_data.csv
Chúc Thầy chấm bài vui vẻ.
