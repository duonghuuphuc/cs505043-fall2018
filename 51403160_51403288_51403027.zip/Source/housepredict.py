import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import mpl_toolkits
from sklearn.linear_model import LinearRegression
from sklearn.model_selection  import train_test_split
from sklearn import ensemble

data  = pd.read_csv("kc_house_data.csv")
model = LinearRegression()
y = data['price']
conv_dates = [1 if values == 2014 else 0 for values in data.date ]
data['date'] = conv_dates
X = data.drop(['id', 'price'],axis=1)
X_train , X_test , y_train , y_test = train_test_split(X , y , test_size = 0.10)
print(model.fit(X_train, y_train))
print("Accuracy --> ", model.score(X_test, y_test)*100)
# df_processed = pd.DataFrame()
# df_processed = df_processed.assign(price_predicted=pd.Series(model.predict(X_test).astype(int)))
# df_processed = df_processed.assign(price_test=pd.Series(y_test.values.astype(int)))
# df_processed.to_csv("processed_data.csv", sep=',', encoding='utf-8')

clf = ensemble.GradientBoostingRegressor(n_estimators = 400, max_depth = 5, min_samples_split = 2,
          learning_rate = 0.1, loss = 'ls')
          

clf.fit(X_train, y_train)
print(clf.score(X_test,y_test))
# print(data.columns[data.isnull().any()])
# df_processed = pd.DataFrame()
# df_processed = df_processed.assign(price_predicted=pd.Series(clf.predict(X_test).astype(int)))
# df_processed = df_processed.assign(price_test=pd.Series(y_test.values.astype(int)))
# df_processed.to_csv("processed_data_clf.csv", sep=',', encoding='utf-8')

print(model.coef_)